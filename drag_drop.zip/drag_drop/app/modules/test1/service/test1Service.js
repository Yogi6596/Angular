test1Module.factory('service1',function($http){
	return function (params){
		return $http.get('name')
	}
})