var test1Module = angular.module('test1Module',[]);
test1Module.controller('test1Controller',['$scope',function($scope){
	console.log('active');
	$scope.d = {};
	$scope.data = [
	{
		"name": "yogita",
		"place": "kpkd"
	}];

	$scope.save = function(){
		$scope.data.push($scope.d);
		console.log($scope.data);
	}

	$scope.edit = function(index){
		$scope.d.name = $scope.data[index].name;
		$scope.d.place = $scope.data[index].place;
	}

	$scope.update = function(){
		$scope.data[0] = $scope.d;
	}
}]);